import { Button } from "@/components/ui/button";
import { DialogHeader } from "@/components/ui/dialog";
import { Dialog, DialogContent, DialogTrigger } from "@/components/ui/dialog";
import { DropdownMenuItem } from "@/components/ui/dropdown-menu";
import { DropdownMenu, DropdownMenuContent, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { PersonIcon } from "@radix-ui/react-icons";
import CreateProjectForm from "../Project/CreateProjectForm";


const Navbar = () => {
    return (
        <div className="border-b py-1 px-3 flex items-center gap-5 bg-yellow-700 text-white">
            {/* Logo Section */}
            <div>
                <img src="icon.png" alt="Project Management Logo" className="h-[70px] w-[70px] rounded-full block" />
            </div>

            {/* Left side buttons (New Project and Upgrade) */}
            <div className="flex items-center gap-5 ml-0">
                <Dialog>
                    <DialogTrigger>
                        <Button variant="default">New Project</Button>
                    </DialogTrigger>
                    <DialogContent>
                        <DialogHeader>Create New Project</DialogHeader>
                        <CreateProjectForm/>
                    </DialogContent>
                </Dialog>
                
                <Button variant="default">Upgrade</Button>
            </div>
          
                
            {/* Right side icon and dropdown (Logout) */}
            <div className="ml-auto flex items-center ">
                <DropdownMenu>
                    <DropdownMenuTrigger>
                        <Button variant="outline" size="icon" className='rounded-full border-2'>
                            <PersonIcon/>
                        </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent>
                        <DropdownMenuItem variant="default">Logout</DropdownMenuItem>
                    </DropdownMenuContent>
                </DropdownMenu>
                <p >Adarsh Dubey</p>
            </div>
        </div>
    );
};

export default Navbar;
